export default function PageContent() {
  return (
    <>
      <style jsx>{`
        div {
          border: 1px solid black;
        }
      `}</style>
      <div>
        This content is loaded dynamically
      </div>
    </>
  );
}