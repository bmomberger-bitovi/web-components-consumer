import Script from 'next/script';
const Breadcrumbs = function ({ routeRoot }) {
    return (<>
      {customElements.get("bread-crumbs") ? null : <Script src="/bread-crumbs.es.js" type="module"/>}
      <bread-crumbs route-root={routeRoot}/>
    </>);
};
export default Breadcrumbs;
//# sourceMappingURL=Breadcrumbs.jsx.map