/// <reference types="react" />
export default function Home(): import("react").JSX.Element;
