/// <reference types="react" />
export default function NavLinks({ routeRoot }: {
    routeRoot?: string;
}): import("react").JSX.Element;
