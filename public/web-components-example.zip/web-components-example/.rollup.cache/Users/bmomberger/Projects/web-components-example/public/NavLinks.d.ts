/// <reference types="react" />
export interface RouteRequestEvent extends CustomEvent {
    data?: {
        href: string;
    };
    originalEvent?: MouseEvent;
}
export default function NavLinks({ routeRoot, initialRoute }: {
    routeRoot: string;
    initialRoute: string;
}): import("react").JSX.Element;
