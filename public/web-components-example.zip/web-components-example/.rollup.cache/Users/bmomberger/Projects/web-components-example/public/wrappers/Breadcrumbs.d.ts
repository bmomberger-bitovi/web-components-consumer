/// <reference types="react" />
import type BaseBreadcrumbs from '../public/Breadcrumbs';
declare global {
    namespace JSX {
        interface IntrinsicElements {
            "bread-crumbs": React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>;
        }
    }
}
declare const Breadcrumbs: typeof BaseBreadcrumbs;
export default Breadcrumbs;
