/// <reference types="react" />
export default function Breadcrumbs({ routeRoot }: {
    routeRoot?: string;
}): import("react").JSX.Element;
